<!DOCTYPE html>
<html lang="en">

<head>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/css/bootstrap-select.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script>

  <?php include VIEWPATH.'includes/header.php' ?>
</head>

<body>
  <div class="container-fluid" style="background-color: white">
    <!-- <div id="wrapper"> -->
      <!-- Navigation -->
      <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 5px" id="navp">
        <!-- /.navbar-top-links -->
        <?php include VIEWPATH. 'includes/menu_principal.php' ?>
        <!-- /.navbar-static-side -->
      </nav>

      <!-- Page Content -->
      <?php 
      $menu1='';
      $menu2='active';
      ?>
      <!-- <div id="page-wrapper"> -->
        <div class="container-fluid">
          <div class="row">

            <div class="col-lg-12" style=" margin-bottom: 5px">
             <div class="row" style="" id="conta">
               <!-- <?= $breadcrumb ?> --><br>
             </div>
             <div class="row" id="conta" style="margin-top: -10px">
               <div class="col-md-6">                                  
                 <h4 class=""><b><?=$title; ?></b></h4>
               </div>
               <!-- <span style="margin-right: 15px"> -->
                <div class="col-md-6 ">
                  <a class="btn btn-sm btn-primary view-more" style="float:right;" href="<?=base_url('cra/Affectation/ajouter')?>"><font class="fa fa-plus"></font>  Nouveau</a>
                </div>

                <!-- </span> -->
                <div class="col-lg-6 col-md-6" style="padding-bottom: 3px">
                 <?php // include 'includes/sous_menu_classe.php'; ?> 
               </div>
             </div>  
           </div>




            <div class="col-lg-12 jumbotron table-responsive" style="padding: 5px">

           <?=  $this->session->flashdata('message');?>
              <table id='mytable' class="table table-bordered table-striped table-hover table-condensed" style="width: 100%;">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Tâche</th>
                    <th>Indicateur</th>
                    <th>Résultat</th>
                    <th>Date début</th>
                    <th>Date fin</th>
                    <th>Projet</th>
                    <th>Collaborateur</th>
                    <th>Actions</th>
                                        
                                              
                  </tr>
                </thead>

              </table> 

            </div>

       


        </div>
      </div>
    </div>
    <!-- </div> -->
    <!-- </div> -->
  </div>

</body>
</html>

<script type="text/javascript">

$('#message').delay('slow').fadeOut(3000);
 $(document).ready(function(){

   liste();

 });


 function liste() 
 {  



  // alert(id)
   $("#mytable").DataTable({
    "destroy" : true,
    "processing":true,
    "serverSide":true,
    "oreder":[[ 1, 'asc' ]],
    "ajax":{
      url: "<?php echo base_url('cra/Affectation/listing/');?>", 
      type:"POST",
      data : {  },
      beforeSend : function() {
      }
    },
    lengthMenu: [[10,50, 100, -1], [10,50, 100, "All"]],
    pageLength: 10,
    "columnDefs":[{
      "targets":[],
      "orderable":false
    }],
    // dom: 'Bfrtlip',
    // buttons: [ 'copy', 'csv', 'excel', 'pdf', 'print'  ],
    language: {
      "sProcessing":     "Traitement en cours...",
      "sSearch":         "Rechercher&nbsp;:",
      "sLengthMenu":     "Afficher _MENU_ &eacute;l&eacute;ments",
      "sInfo":           "Affichage de l'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments",
      "sInfoEmpty":      "Affichage de l'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment",
      "sInfoFiltered":   "(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)",
      "sInfoPostFix":    "",
      "sLoadingRecords": "Chargement en cours...",
      "sZeroRecords":    "Aucun &eacute;l&eacute;ment &agrave; afficher",
      "sEmptyTable":     "Aucune donn&eacute;e disponible dans le tableau",
      "oPaginate": {
        "sFirst":      "Premier",
        "sPrevious":   "Pr&eacute;c&eacute;dent",
        "sNext":       "Suivant",
        "sLast":       "Dernier"
      },
      "oAria": {
        "sSortAscending":  ": activer pour trier la colonne par ordre croissant",
        "sSortDescending": ": activer pour trier la colonne par ordre d&eacute;croissant"
      }
    }
  });


 }
</script>

 





 




                
