<!DOCTYPE html>
<html lang="en">

<head>

 


  <?php include VIEWPATH.'includes/header.php' ?>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/css/bootstrap-select.min.css">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script>
</head>

<body>
  <div class="container-fluid" style="background-color: white">
    <!-- <div id="wrapper"> -->
      <!-- Navigation -->
      <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 5px" id="navp">
        <!-- /.navbar-top-links -->
        <?php include VIEWPATH. 'includes/menu_principal.php' ?>
        <!-- /.navbar-static-side -->
      </nav>

      <!-- Page Content -->
      <?php 
      $menu1='';
      $menu2='active';
      ?>
      <!-- <div id="page-wrapper"> -->
        <div class="container-fluid">
          <div class="row">

            <div class="col-lg-12" style=" margin-bottom: 5px">
             <div class="row" style="" id="conta">
               <!-- <?= $breadcrumb ?> --><br>
             </div>
             <div class="row" id="conta" style="margin-top: -10px">
               <div class="col-md-6">                                  
                 <h4 class=""><b><?=$title; ?></b></h4>
               </div>
               <!-- <span style="margin-right: 15px"> -->
                <div class="col-md-6 ">
                  <a  class="btn btn-sm btn-primary view-more" style="float:right;" href="<?=base_url('cra/Affectation/')?>"><font class="fa fa-list"></font>  Liste</a>
                </div>

                <!-- </span> -->
                <div class="col-lg-6 col-md-6" style="padding-bottom: 3px">
                 <?php // include 'includes/sous_menu_classe.php'; ?> 
               </div>
             </div>  
           </div>




           <div class="col-lg-12 jumbotron table-responsive" style="padding: 5px">
            <?=  $this->session->flashdata('message');?>
            
            <form method="post" class="form-horizontal" action="<?=base_url('cra/Affectation/add') ?>" name="myform"  >

              <div class="row">
                <div class="col-md-6">
                  <label for="nom">Tâche</label>
                  <select class="form-control" data-live-search="true" name="TACHE_ID" id="TACHE_ID" >
                    <option value="" > Séléctionner </option>
                    <?php foreach ($tache as $key) {
                      if ($key['TACHE_ID'] == set_value('TACHE_ID') ) {
                        echo "<option value='".$key['TACHE_ID']."' selected >".$key['DESCRIPTION_TACHE']. "</option>'";
                      }else{
                        echo "<option value='".$key['TACHE_ID']."' >".$key['DESCRIPTION_TACHE']. "</option>'";
                      }
                    }?>
                  </select>
                  <?php echo form_error('TACHE_ID', '<div class="text-danger">', '</div>'); ?> 
                </div>

                <div class="col-md-6">
                  <label>Collaborateur</label>
                  


                  <select name="ID_COLLABORATEUR[]" class="form-control selectpicker"   data-live-search="true" multiple>
                    <option value="">Séléctionner</option>
                    <?php
                    foreach ($collaborateurs as $key_ville) {

                      if(in_array($key_ville['ID_COLLABORATEUR'],$exist)) 
                        {  ?>
                          <option value="<?=$key_ville['ID_COLLABORATEUR']?>" selected><?=$key_ville['NOM'].' '.$key['PRENOM']?></option> 
                        <?php   } else {
                          echo "<option value=".$key_ville['ID_COLLABORATEUR']." >".$key_ville['NOM'].' '.$key_ville['PRENOM'] ." </option>";
                        }
                      }
                      ?>       
                    </select> 

                    <?php echo form_error('ID_COLLABORATEUR', '<div class="text-danger">', '</div>'); ?> 

                  </div>

                  <div class="col-md-6">
                    <label>Date début</label>
                    <input type="date" class="form-control" name="DATE_DEBUT" min="<?=date('Y-m-d')?>">
                    <?php echo form_error('DATE_DEBUT', '<div class="text-danger">', '</div>'); ?> 
                  </div>

                  <div class="col-md-6">
                    <label>Date fin</label>
                    <input type="date" class="form-control" name="DATE_FIN" min="<?=date('Y-m-d')?>">
                    <?php echo form_error('DATE_FIN', '<div class="text-danger">', '</div>'); ?> 
                  </div>


                  


                  <div class="col-md-12">
                    <br><button type="submit" class="btn btn-primary float-right mt-4" style="float:right;"><span class="fa fa-save"></span> Enregistrer</button>
                  </div>

                </div>
                
              </form>

            </div>

            


          </div>
        </div>
      </div>
      <!-- </div> -->
      <!-- </div> -->
    </div>

  </body>
  </html>

  <script type="text/javascript">
    $('#message').delay('slow').fadeOut(3000);
  </script>

  <script>
   
   document.getElementById("DATE_FIN").setAttribute("min", today);
    // document.getElementById("DATE_DEBUT").setAttribute("max", today);
    document.getElementById("DATE_DEBUT").setAttribute("min", today);
  </script>

  
