<!DOCTYPE html>
<html lang="en">

<head>

  <?php include VIEWPATH.'includes/header.php' ?>
</head>

<body>
  <div class="container-fluid" style="background-color: white">
    <!-- <div id="wrapper"> -->
      <!-- Navigation -->
      <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 5px" id="navp">
        <!-- /.navbar-top-links -->
        <?php include VIEWPATH. 'includes/menu_principal.php' ?>
        <!-- /.navbar-static-side -->
      </nav>

      <!-- Page Content -->
      <?php 
      $menu1='';
      $menu2='active';
      ?>
      <!-- <div id="page-wrapper"> -->
        <div class="container-fluid">
          <div class="row">

            <div class="col-lg-12" style=" margin-bottom: 5px">
             <div class="row" style="" id="conta">
               <!-- <?= $breadcrumb ?> --><br>
             </div>
             <div class="row" id="conta" style="margin-top: -10px">
               <div class="col-md-6">                                  
                 <h4 class=""><b><?=$title; ?></b></h4>
               </div>
               <!-- <span style="margin-right: 15px"> -->
                <div class="col-md-6 ">
                  <a  class="btn btn-sm btn-primary view-more" style="float:right;" href="<?=base_url('cra/Collaborateurs/')?>"><font class="fa fa-list"></font>  Liste</a>
                </div>

                <!-- </span> -->
                <div class="col-lg-6 col-md-6" style="padding-bottom: 3px">
                 <?php // include 'includes/sous_menu_classe.php'; ?> 
               </div>
             </div>  
           </div>




            <div class="col-lg-12 jumbotron table-responsive" style="padding: 5px">

           
             <form method="post" class="form-horizontal" action="<?=base_url('cra/Collaborateurs/add') ?>" name="myform"  >

              <div class="row">
                <div class="col-md-6">
                  <label for="nom">Intervenant</label>
                  <select class="form-control select2" data-live-search="true" name="ID_INTERVENANT" id="ID_INTERVENANT" >
                    <option value="" > Séléctionner </option>
                    <?php foreach ($intervenant as $key) {
                      if ($key['ID_INTERVENANT'] == set_value('ID_INTERVENANT') ) {
                        echo "<option value='".$key['ID_INTERVENANT']."' selected >".$key['NOM'].' '.$key['PRENOM']. "</option>'";
                      }else{
                        echo "<option value='".$key['ID_INTERVENANT']."' >".$key['NOM'].' '.$key['PRENOM']."</option>'";
                      }
                    }?>
                  </select>
                  <?php echo form_error('ID_INTERVENANT', '<div class="text-danger">', '</div>'); ?> 
                  </div>

                <div class="col-md-6">
                  <label>Nom</label>
                  <input type="text" class="form-control" name="NOM" va>
                  <?php echo form_error('NOM', '<div class="text-danger">', '</div>'); ?> 
                </div>

                <div class="col-md-6">
                  <label>Prénom</label>
                  <input type="text" class="form-control" name="PRENOM">
                  <?php echo form_error('PRENOM', '<div class="text-danger">', '</div>'); ?> 
                </div>

                <div class="col-md-6">
                  <label>Téléphone</label>
                  <input type="number" class="form-control" name="TEL">
                  <?php echo form_error('TEL', '<div class="text-danger">', '</div>'); ?> 
                </div>

                <div class="col-md-6">
                  <label>Email</label>
                  <input type="email" class="form-control" name="EMAIL">
                  <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?> 
                </div>

                 <div class="col-md-6">What version of jQuery are you using? You need to load jQuery before bootstrap-select.min.js.

￼
￼
26

                  <label>Date de naissance</label>
                  <input type="date" class="form-control" name="DATE_NAISSANCE" max="<?=date('Y-m-d')?>" >
                  <?php echo form_error('DATE_NAISSANCE', '<div class="text-danger">', '</div>'); ?> 
                </div>

                <div class="col-md-6">
                  <label>Lieu de naissance</label>
                  <input type="text" class="form-control" name="LIEU_NAISSANCE">
                  <?php echo form_error('LIEU_NAISSANCE', '<div class="text-danger">', '</div>'); ?> 
                </div>

                <div class="col-md-6">
                  <label>Adresse</label>
                  <input type="text" class="form-control" name="ADRESSE">
                  <?php echo form_error('ADRESSE', '<div class="text-danger">', '</div>'); ?> 
                </div>


                <div class="col-md-6">
                  <label for="nom">Fonction</label>
                  <select class="form-control select2" data-live-search="true" name="FONCTION_ID" id="FONCTION_ID" >
                    <option value="" > Séléctionner </option>
                    <?php foreach ($fonction as $key) {
                      if ($key['ID_FONCTION_UNWOMAN'] == set_value('FONCTION_ID') ) {
                        echo "<option value='".$key['ID_FONCTION_UNWOMAN']."' selected >".$key['DESCRIPTION']."</option>'";
                      }else{
                        echo "<option value='".$key['ID_FONCTION_UNWOMAN']."' >".$key['DESCRIPTION']."</option>'";
                      }
                    }?>
                  </select>
                  <?php echo form_error('FONCTION_ID', '<div class="text-danger">', '</div>'); ?> 
                  </div>


              <div class="col-md-6">
                <br><button type="submit" class="btn btn-primary float-right mt-4" style="float:right;"><span class="fa fa-save"></span> Enregistrer</button>
              </div>

              </div>
               
             </form>

            </div>

       


        </div>
      </div>
    </div>
    <!-- </div> -->
    <!-- </div> -->
  </div>

</body>
</html>




                
