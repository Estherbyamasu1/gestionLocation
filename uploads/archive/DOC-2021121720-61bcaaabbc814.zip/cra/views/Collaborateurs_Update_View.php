<!DOCTYPE html>
<html lang="en">

<head>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/css/bootstrap-select.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script>

  <?php include VIEWPATH.'includes/header.php' ?>
</head>

<body>
  <div class="container-fluid" style="background-color: white">
    <!-- <div id="wrapper"> -->
      <!-- Navigation -->
      <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 5px" id="navp">
        <!-- /.navbar-top-links -->
        <?php include VIEWPATH. 'includes/menu_principal.php' ?>
        <!-- /.navbar-static-side -->
      </nav>

      <!-- Page Content -->
      <?php 
      $menu1='';
      $menu2='active';
      ?>
      <!-- <div id="page-wrapper"> -->
        <div class="container-fluid">
          <div class="row">

            <div class="col-lg-12" style=" margin-bottom: 5px">
             <div class="row" style="" id="conta">
               <!-- <?= $breadcrumb ?> --><br>
             </div>
             <div class="row" id="conta" style="margin-top: -10px">
               <div class="col-md-6">                                  
                 <h4 class=""><b><?=$title; ?></b></h4>
               </div>
               <!-- <span style="margin-right: 15px"> -->
                <div class="col-md-6 ">
                  <a class="btn btn-sm btn-primary view-more" style="float:right;" href="<?=base_url('cra/Collaborateurs/')?>"><font class="fa fa-list"></font>  Liste</a>
                </div>

                <!-- </span> -->
                <div class="col-lg-6 col-md-6" style="padding-bottom: 3px">
                 <?php // include 'includes/sous_menu_classe.php'; ?> 
               </div>
             </div>  
           </div>




            <div class="col-lg-12 jumbotron table-responsive" style="padding: 5px">

           
             <form method="post" class="form-horizontal" action="<?=base_url('cra/Collaborateurs/update') ?>" name="myform">

              <div class="row">
              <div class="col-md-6">
                <input type="hidden" class="form-control" name="ID_COLLABORATEUR" value="<?=$data['ID_COLLABORATEUR']?>" >

                <label for="FName">Intervenant</label>
                <select  name="ID_INTERVENANT" class="form-control" data-live-search="true">
                        
                    <?php
                    foreach ($intervenant as $value) {
                      if ($colla['ID_INTERVENANT']==$value['ID_INTERVENANT']) 
                      {
                        echo "<option value=".$value['ID_INTERVENANT']." selected=''>".$value['NOM'].' '.$value['PRENOM']. "</option>";
                      } else {
                        echo "<option value=".$value['ID_INTERVENANT'].">".$value['NOM'].' '.$value['PRENOM']. " </option>";
                      }
                    }
                    ?>           
                 </select>
                <?php echo form_error('ID_INTERVENANT', '<div class="text-danger">', '</div>'); ?> 

              </div>

              <div class="col-md-6">
                <label for="LName">Nom</label>
                <input type="text" name="NOM" value="<?=$data['NOM'] ?>"  id="NOM" class="form-control">
                <?php echo form_error('NOM', '<div class="text-danger">', '</div>'); ?> 

              </div>
            </div>

            <div class="row">
              
             <div class="col-md-6">
              <label for="LName">Prénom</label>
              <input type="text" name="PRENOM" id="PRENOM" autocomplete="off" value="<?= $data['PRENOM'] ?>" class="form-control">
              <?php echo form_error('PRENOM', '<div class="text-danger">', '</div>'); ?> 

            </div>

            <div class="col-md-6">
              <label for="LName">Téléphone</label>
              <input type="number" name="TEL" id="TEL" value="<?= $data['TEL'] ?>" class="form-control">
              <?php echo form_error('TEL', '<div class="text-danger">', '</div>'); ?> 

            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <label for="LName">Email</label>
              <input type="email" name="EMAIL" id="EMAIL" value="<?= $data['EMAIL'] ?>" class="form-control">
              <?php echo form_error('EMAIL', '<div class="text-danger">', '</div>'); ?> 

            </div>
            <div class="col-md-6">
              <label>Date de naissance</label>
              <input type="date" class="form-control" name="DATE_NAISSANCE" max="<?=date('Y-m-d')?>" value="<?=$data['DATE_NAISSANCE'] ?>" >
              <?php echo form_error('DATE_NAISSANCE', '<div class="text-danger">', '</div>'); ?> 

            </div>

            
          </div>
          <div class="row">

            <div class="col-md-6">
              <label>Lieu de naissance</label>
              <input type="text" class="form-control" name="LIEU_NAISSANCE" value="<?=$data['LIEU_NAISSANCE'] ?>">
              <?php echo form_error('LIEU_NAISSANCE', '<div class="text-danger">', '</div>'); ?> 

            </div>

            <div class="col-md-6">
              <label>Adresse</label>
              <input type="text" class="form-control" name="ADRESSE" value="<?=$data['ADRESSE'] ?>">
              <?php echo form_error('ADRESSE', '<div class="text-danger">', '</div>'); ?> 
            </div>
          </div>

          <div class="row">

            <div class="col-md-6">
              <label for="LName">Fonction</label>

              <select  name="FONCTION_ID" class="form-control" data-live-search="true">
                        
                <?php
                foreach ($fonction as $value) {
                  if ($data['FONCTION_ID']==$value['ID_FONCTION_UNWOMAN']) 
                  {
                    echo "<option value=".$value['ID_FONCTION_UNWOMAN']." selected=''>".$value['DESCRIPTION']."</option>";
                  } else {
                    echo "<option value=".$value['ID_FONCTION_UNWOMAN'].">".$value['DESCRIPTION']." </option>";
                  }
                }
                ?>           
               </select>
             <?php echo form_error('TYPE_INTERVENANT_STRUCTURE_ID', '<div class="text-danger">', '</div>'); ?> 

           </div>

           <div class="col-md-6" style="margin-top:31px;">
            <button type="submit" style="float: right;" class="btn btn-primary"><span class="fa fa-edit"></span> Modifier</button>
          
          </div>
        </div>



               
             </form>

            </div>

       


        </div>
      </div>
    </div>
    <!-- </div> -->
    <!-- </div> -->
  </div>

</body>
</html>




                
