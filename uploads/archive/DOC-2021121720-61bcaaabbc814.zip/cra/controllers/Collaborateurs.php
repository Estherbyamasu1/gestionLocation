<?php 
/**
 * christa
 */
class Collaborateurs extends CI_Controller
{
	
	function __construct()
	{
		// code...
		parent::__construct();
	}

	function index()
	{
		$data['title'] = 'Collaborateurs';
		$this->load->view('Collaborateurs_List_View',$data);
	}

	function listing()
	{
		$query_principal='SELECT cra_collaborateur.ID_COLLABORATEUR,cra_collaborateur.NOM,cra_collaborateur.`PRENOM`,se_intervenant.NOM as interv_nom,se_intervenant.PRENOM as interv_prenom,cra_collaborateur.`TEL`,cra_collaborateur.`EMAIL`,date_format(cra_collaborateur.`DATE_NAISSANCE`,"%d-%m-%Y")AS date_naissance,cra_collaborateur.`LIEU_NAISSANCE`, cra_collaborateur.`ADRESSE`,fonc.DESCRIPTION FROM `cra_collaborateur` JOIN se_intervenant ON cra_collaborateur.ID_INTERVENANT=se_intervenant.ID_INTERVENANT JOIN se_rh_fonction_unwoman fonc ON cra_collaborateur.FONCTION_ID=fonc.ID_FONCTION_UNWOMAN WHERE 1';

		$var_search= !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

		$limit='LIMIT 0,10';


		if($_POST['length'] != -1){
			$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		}
		$order_by='';



		$order_column=array('cra_collaborateur.NOM');

		if ($order_by) {
			# code...
			$order_by = isset($_POST['order']) ? ' ORDER BY '.$order_column[$_POST['order']['0']['column']] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY cra_collaborateur.NOM  ASC';
		}
		

		$search = !empty($_POST['search']['value']) ? (" AND cra_collaborateur.NOM LIKE '%$var_search%' or cra_collaborateur.PRENOM LIKE '%var_search%' or cra_collaborateur.LIEU_NAISSANCE LIKE '%$var_search%' ") : '';     

		$critaire = '';

		$query_secondaire=$query_principal.' '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
		$query_filter = $query_principal.' '.$critaire.' '.$search;

		$abonne='';
		
		$fetch_collaborateus = $this->Model->datatable($query_secondaire);
		$data = array();
		$u=0;
		foreach ($fetch_collaborateus as $row) {

		
			$u++;
			$sub_array = array();
			$sub_array[] =  $u;
			$sub_array[]=$row->NOM.' '.$row->PRENOM; 
			$sub_array[]=$row->interv_nom.' '.$row->interv_prenom; 
			$sub_array[]=$row->TEL;
			$sub_array[]= $row->EMAIL;
			$sub_array[]=$row->date_naissance;
			$sub_array[]=$row->LIEU_NAISSANCE; 
			$sub_array[]=$row->ADRESSE; 
			$sub_array[]=$row->DESCRIPTION; 
			

			$option = '<div class="dropdown" style="color:#fff;">
            <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cog">
            </i> Options  <span class="caret"></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-left">';

            $option.= "<li><a hre='#' data-toggle='modal'
            data-target='#mydelete" . $row->ID_COLLABORATEUR . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
            $option .= "<li><a class='btn-md' href='" . base_url('cra/Collaborateurs/getOne/'. $row->ID_COLLABORATEUR) . "'>&nbsp;&nbsp;Modifier</a></li>";

            $option .= " </ul>
            </div>
            <div class='modal fade' id='mydelete".$row->ID_COLLABORATEUR."'>
            <div class='modal-dialog'>
            <div class='modal-content'>

            <div class='modal-body'>
            <center>
            <h5><strong>Voulez-vous supprimer? </strong><br><b style='background-color:prink;color:green;'>
            <i>" . $row->NOM.' '.$row->PRENOM."</i></b>
            </h5>
            </center>
            </div>

            <div class='modal-footer'>
            <a class='btn btn-danger btn-md' href='" . base_url('cra/Collaborateurs/delete/').$row->ID_COLLABORATEUR . "'>Supprimer
            </a>
            <button class='btn btn-primary btn-md' data-dismiss='modal'>
            Quitter
            </button>
            </div>

            </div>
            </div>
            </div>";


			$sub_array[]=$option;

			$data[] = $sub_array;
		}
		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" =>$this->Model->all_data($query_principal),
			"recordsFiltered" => $this->Model->filtrer($query_filter),
			"data" => $data
		);
		echo json_encode($output);
	}


	function ajouter()
	{
		$data['intervenant']= $this->Model->getRequete('SELECT `ID_INTERVENANT`,`NOM`,`PRENOM` FROM `se_intervenant` WHERE 1 ORDER BY `NOM` ASC');

		$data['fonction']= $this->Model->getRequete('SELECT `ID_FONCTION_UNWOMAN`,`DESCRIPTION` FROM `se_rh_fonction_unwoman` WHERE 1 ORDER BY `DESCRIPTION` ASC');

		$data['title'] = 'Collaborateurs';
		$this->load->view('Collaborateurs_Add_View',$data);
	}

	function add()
	{
		$this->form_validation->set_rules('ID_INTERVENANT','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('NOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('PRENOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('TEL','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('EMAIL','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('DATE_NAISSANCE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('LIEU_NAISSANCE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('ADRESSE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('FONCTION_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		if ($this->form_validation->run() == FALSE)
	    {
	        $this->ajouter();
	    }else{

	    	$dataInsert=array(
               'ID_INTERVENANT'=>$this->input->post('ID_INTERVENANT'),
               'NOM'=>$this->input->post('NOM'),
               'PRENOM'=>$this->input->post('PRENOM'),
               'TEL'=>$this->input->post('TEL'),
               'EMAIL'=>$this->input->post('EMAIL'),
               'DATE_NAISSANCE'=>$this->input->post('DATE_NAISSANCE'),
               'LIEU_NAISSANCE'=>$this->input->post('LIEU_NAISSANCE'),
               'ADRESSE'=>$this->input->post('ADRESSE'),
               'FONCTION_ID'=>$this->input->post('FONCTION_ID')
               );

	    	$this->Model->create('cra_collaborateur',$dataInsert);

		    $data['message']='<div class="alert alert-success text-center" id="message">'."L'enregistrement d'un collaborateur <b>".' '.$this->input->post('NOM').'</b> '." est faite avec succès".'</div>';
		    $this->session->set_flashdata($data);
		    redirect(base_url('cra/Collaborateurs/'));
	    }

	}




	function getOne()
	{

		$id=$this->uri->segment(4);
		$data['intervenant']= $this->Model->getRequete('SELECT `ID_INTERVENANT`,`NOM`,`PRENOM` FROM `se_intervenant` WHERE 1 ORDER BY `NOM` ASC');

		$data['fonction']= $this->Model->getRequete('SELECT `ID_FONCTION_UNWOMAN`,`DESCRIPTION` FROM `se_rh_fonction_unwoman` WHERE 1 ORDER BY `DESCRIPTION` ASC');

		$data['data']=$this->Model->getOne('cra_collaborateur',array('ID_COLLABORATEUR'=>$id));

		$data['title'] = 'Collaborateurs';
		$this->load->view('Collaborateurs_Update_View',$data);

	}

	function update()
	{
		$this->form_validation->set_rules('ID_INTERVENANT','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('NOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('PRENOM','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('TEL','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('EMAIL','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('DATE_NAISSANCE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('LIEU_NAISSANCE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('ADRESSE','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));
		$this->form_validation->set_rules('FONCTION_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));


		if ($this->form_validation->run() == FALSE) {

			$this->getOne();
		}else{

			$id=$this->input->post('ID_COLLABORATEUR');

			$data=array(
					   'ID_INTERVENANT'=>$this->input->post('ID_INTERVENANT'),
		               'NOM'=>$this->input->post('NOM'),
		               'PRENOM'=>$this->input->post('PRENOM'),
		               'TEL'=>$this->input->post('TEL'),
		               'EMAIL'=>$this->input->post('EMAIL'),
		               'DATE_NAISSANCE'=>$this->input->post('DATE_NAISSANCE'),
		               'LIEU_NAISSANCE'=>$this->input->post('LIEU_NAISSANCE'),
		               'ADRESSE'=>$this->input->post('ADRESSE'),
		               'FONCTION_ID'=>$this->input->post('FONCTION_ID')
					
			);
		$this->Model->update('cra_collaborateur',array('ID_COLLABORATEUR'=>$id),$data);


		$datas['message']='<div class="alert alert-success text-center" id="message">La modification d\'un collaborateur '.$this->input->post('NOM').' '.$this->input->post('PRENOM'). ' est faite avec succès</div>';
		$this->session->set_flashdata($datas);
		redirect(base_url('cra/Collaborateurs/'));
		}
	}

	function delete()
	{
	    $table="cra_collaborateur";
	    $criteres['ID_COLLABORATEUR']=$this->uri->segment(4);

	    $this->Model->delete($table,$criteres);
	    $data['message']='<div class="alert alert-success text-center" id="message">'."Le collaborateur <b> ".' '.$data['rows']['NOM'].' </b> '." est supprimé avec succès".'</div>';
	    $this->session->set_flashdata($data);
	    redirect(base_url('cra/Collaborateurs/index'));
	}

}
 ?>