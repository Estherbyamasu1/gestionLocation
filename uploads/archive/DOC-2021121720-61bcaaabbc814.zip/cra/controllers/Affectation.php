<?php 
/**
 * christa
 */
class Affectation extends CI_Controller
{
	
	function __construct()
	{
		// code...
		parent::__construct();
	}

	function index()
	{
		$data['title'] = 'Affectation des tâches';
		$this->load->view('Affectation_View',$data);
	}

	function listing()
	{
		$query_principal='SELECT aff.TACHE_ID,aff.`TACHE_AFFECTATION_ID`,cra_taches.DESCRIPTION_TACHE,se_indicateur.DESCR_KPI,se_resultat.DESCR_RESULTAT,date_format(aff.`DATE_DEBUT`,"%d-%m-%Y")AS debut,date_format(aff.`DATE_FIN`,"%d-%m-%Y")AS fin,se_projet.NOM AS projet,cra_collaborateur.NOM ,cra_collaborateur.PRENOM FROM `cra_tache_affectation` aff LEFT JOIN cra_taches ON aff.`TACHE_ID`=cra_taches.TACHE_ID LEFT JOIN se_indicateur ON cra_taches.ID_KPI=se_indicateur.ID_KPI LEFT JOIN se_resultat ON cra_taches.ID_RESULTAT=se_resultat.ID_RESULTAT JOIN se_projet ON cra_taches.ID_PROJET=se_projet.ID_PROJET LEFT JOIN cra_collaborateur ON aff.`ID_COLLABORATEUR`=cra_collaborateur.ID_COLLABORATEUR WHERE 1 ';


		$var_search= !empty($_POST['search']['value']) ? $_POST['search']['value'] : null;

		$limit='LIMIT 0,10';


		if($_POST['length'] != -1){
			$limit='LIMIT '.$_POST["start"].','.$_POST["length"];
		}
		$order_by='';



		$order_column=array('aff.`TACHE_AFFECTATION_ID`','cra_taches.DESCRIPTION_TACHE','se_resultat.DESCR_RESULTAT','aff.`DATE_DEBUT`','aff.`DATE_FIN`','se_projet.NOM','cra_collaborateur.NOM','cra_collaborateur.NOM','cra_collaborateur.NOM');
		if ($order_by) {
			# code...
			$order_by = isset($_POST['order']) ? ' ORDER BY '.$order_column[$_POST['order']['0']['column']] .'  '.$_POST['order']['0']['dir'] : ' ORDER BY cra_taches.DESCRIPTION_TACHE  ASC';
		}
		

		$search = !empty($_POST['search']['value']) ? (" AND cra_taches.DESCRIPTION_TACHE LIKE '%$var_search%' or se_indicateur.DESCR_KPI LIKE '%var_search%' or se_resultat.DESCR_RESULTAT LIKE '%$var_search%' ") : '';     

		$critaire = '';

		$query_secondaire=$query_principal.' '.$critaire.' '.$search.' '.$order_by.'   '.$limit;
		$query_filter = $query_principal.' '.$critaire.' '.$search;

		$abonne='';
		
		$fetch_affectation = $this->Model->datatable($query_secondaire);
		$data = array();
		$u=0;
		foreach ($fetch_affectation as $row) {

		
			$u++;
			$sub_array = array();
			$sub_array[] =  $u;
			$sub_array[]=$row->DESCRIPTION_TACHE; 
			$sub_array[]=$row->DESCR_KPI; 
			$sub_array[]=$row->DESCR_RESULTAT;
			$sub_array[]= $row->debut;
			$sub_array[]=$row->fin;
			$sub_array[]=$row->projet;
			$sub_array[]=$row->NOM.' '.$row->PRENOM; 
			 
			

			$option = '<div class="dropdown" style="color:#fff;">
            <a class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-cog">
            </i> Options  <span class="caret"></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-left">';

            $option.= "<li><a hre='#' data-toggle='modal'
            data-target='#mydelete" . $row->TACHE_AFFECTATION_ID . "'><font color='red'>&nbsp;&nbsp;Supprimer</font></a></li>";
            $option .= "<li><a class='btn-md' href='" . base_url('cra/Affectation/getOne/'. $row->TACHE_AFFECTATION_ID) . "'>&nbsp;&nbsp;Modifier</a></li>";
            $option .= "<li><a class='btn-md' href='" . base_url('cra/Compte_Rendu_Activites/index/'. $row->TACHE_AFFECTATION_ID) . "'>&nbsp;&nbsp;CRA</a></li>";

            $option .= " </ul>
            </div>
            <div class='modal fade' id='mydelete".$row->TACHE_AFFECTATION_ID."'>
            <div class='modal-dialog'>
            <div class='modal-content'>

            <div class='modal-body'>
            <center>
            <h5><strong>Voulez-vous supprimer? </strong><br><b style='background-color:prink;color:green;'>
            <i>" . $row->DESCRIPTION_TACHE."</i></b>
            </h5>
            </center>
            </div>

            <div class='modal-footer'>
            <a class='btn btn-danger btn-md' href='" . base_url('cra/Affectation/delete/').$row->TACHE_AFFECTATION_ID . "'>Supprimer
            </a>
            <button class='btn btn-primary btn-md' data-dismiss='modal'>
            Quitter
            </button>
            </div>

            </div>
            </div>
            </div>";


			$sub_array[]=$option;

			$data[] = $sub_array;
		}
		$output = array(
			"draw" => intval($_POST['draw']),
			"recordsTotal" =>$this->Model->all_data($query_principal),
			"recordsFiltered" => $this->Model->filtrer($query_filter),
			"data" => $data
		);
		echo json_encode($output);
	}

	function ajouter()
	{
		$data['tache']=$this->Model->getRequete('SELECT `TACHE_ID`,`DESCRIPTION_TACHE` FROM `cra_taches` WHERE 1 ORDER BY `DESCRIPTION_TACHE` ASC');

	
		$data['collaborateurs']=$this->Model->getRequete('SELECT `ID_COLLABORATEUR`,`NOM`,`PRENOM` FROM `cra_collaborateur` WHERE 1 ORDER BY `NOM` ASC');
		$data['exist']=array();

		$data['title'] = 'Nouvelle affectation';
		$this->load->view('Affectation_Add_View',$data);
	}

	function add()
	{
		$this->form_validation->set_rules('TACHE_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('DATE_DEBUT','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('DATE_FIN','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('ID_COLLABORATEUR[]','', 'trim|required',array(
			'required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		if ($this->form_validation->run() == FALSE)
		{
			$data['tache']=$this->Model->getRequete('SELECT `TACHE_ID`,`DESCRIPTION_TACHE`,`DATE_DEBUT`,`DATE_FIN` FROM `cra_taches` WHERE 1 ORDER BY `DESCRIPTION_TACHE` ASC');


			$data['collaborateurs']=$this->Model->getRequete('SELECT `ID_COLLABORATEUR`,`NOM`,`PRENOM` FROM `cra_collaborateur` WHERE 1 ORDER BY `NOM` ASC');
			$data['exist']=array();
			$data_collabo=$this->input->post('ID_COLLABORATEUR');
        	$data['exist']=$data_collabo;

			$data['title'] = 'Nouvelle affectation';
			$this->load->view('Affectation_Add_View',$data);
		}else{



			$TACHE_ID=$this->input->post('TACHE_ID');
			$DATE_DEBUT=$this->input->post('DATE_DEBUT');
			$DATE_FIN=$this->input->post('DATE_FIN');

			$USER_ID=$this->session->userdata('WASILI_EAT_USER_ID');

			$date_tache=$this->Model->getRequeteOne('SELECT `TACHE_ID`,`DESCRIPTION_TACHE`,`DATE_DEBUT`,`DATE_FIN` FROM `cra_taches` WHERE TACHE_ID='.$this->input->post('TACHE_ID').' ORDER BY `DESCRIPTION_TACHE` ASC');

			$tache_date_debut=$date_tache['DATE_DEBUT'];
			$tache_date_fin=$date_tache['DATE_FIN'];


			$data_collabo=$this->input->post('ID_COLLABORATEUR');

			$indicateur=$this->Model->getRequeteOne('SELECT `ID_KPI` FROM `cra_taches` WHERE `TACHE_ID`='.$TACHE_ID);
			$ID_KPI=$indicateur['ID_KPI'];

			$resultat=$this->Model->getRequeteOne('SELECT `ID_RESULTAT` FROM `cra_taches` WHERE `TACHE_ID`='.$TACHE_ID);
			$ID_RESULTAT=$resultat['ID_RESULTAT'];

			$projet=$this->Model->getRequeteOne('SELECT `ID_PROJET` FROM `cra_taches` WHERE `TACHE_ID`='.$TACHE_ID);
			$ID_PROJET=$projet['ID_PROJET'];
	

				
			    foreach ($data_collabo as $value) {

				  	$dataInsert=array(
					'TACHE_ID'=>$TACHE_ID,
					'ID_KPI'=>$ID_KPI,
					'ID_RESULTAT'=>$ID_RESULTAT,
					'DATE_DEBUT'=>$DATE_DEBUT,
					'DATE_FIN'=>$DATE_FIN,
					'ID_PROJET'=>$ID_PROJET,
					'ID_USER'=>$USER_ID,
					'ID_COLLABORATEUR'=>$value,
					);

				  	$doub=$this->Model->getOne('cra_tache_affectation',$dataInsert);

				  	if (empty($doub)) {
				  		// code...
				  	
				  	if ($DATE_DEBUT>=$tache_date_debut && $DATE_FIN<=$tache_date_fin) {
				  		// code...
				  	
					$fin_tache=$this->Model->getRequeteOne('SELECT cra_taches.IS_FINISH FROM `cra_tache_affectation` JOIN cra_taches ON cra_tache_affectation.TACHE_ID=cra_taches.TACHE_ID WHERE cra_taches.`TACHE_ID`='.$TACHE_ID);
					$IS_FINISH=$fin_tache['IS_FINISH'];

					// print_r($IS_FINISH);die();

						if ($IS_FINISH ==0) {
							// code...
							$this->Model->create('cra_tache_affectation',$dataInsert);

							/* pour les notifications */

							 $collaborateur=$this->Model->getRequeteOne('SELECT `ID_COLLABORATEUR`,`NOM`,`PRENOM`,EMAIL FROM `cra_collaborateur` WHERE ID_COLLABORATEUR='.$value);

							 $tache=$this->Model->getRequeteOne('SELECT `TACHE_ID`,`DESCRIPTION_TACHE` FROM `cra_taches` WHERE TACHE_ID='.$this->input->post('TACHE_ID'));

							 $email=$collaborateur['EMAIL'];

							 $message = 'Bonjour/Bonsoir '.$collaborateur['NOM'].' '.$collaborateur['PRENOM'].' Vous êtes planifié sur la tâche '.$tache['DESCRIPTION_TACHE'].' ';


							 $this->notifications->send_mail(array($email),"Affectation des tâches",array(),$message,array());
							
						}
						else{
							$data['message']='<div class="alert alert-success text-center" id="message"> La tâche est déjà terminée </div>';
						    $this->session->set_flashdata($data);
						    redirect(base_url('cra/Affectation/ajouter'));
						}

					}else{
						$data['message']='<div class="alert alert-success text-center" id="message"> La date doit être entre la date début  et la date fin de la tâche</div>';
				    $this->session->set_flashdata($data);
				    redirect(base_url('cra/Affectation/ajouter'));
					}

					}else{
						$data['message']='<div class="alert alert-success text-center" id="message"> Le collaborateur est déjà affecté sur cette tache</div>';
				    $this->session->set_flashdata($data);
				    redirect(base_url('cra/Affectation/ajouter'));
					}

				
				
			  }

			  $data['message']='<div class="alert alert-success text-center" id="message">'."L'affectation sur l'activité  <b>".' '.$this->input->post('DESCRIPTION_TACHE').'</b> '." est faite avec succès".'</div>';
				    $this->session->set_flashdata($data);
				    redirect(base_url('cra/Affectation/'));



		}
	}


	function getOne()
	{
		$id=$this->uri->segment(4);
		$data['tache']=$this->Model->getRequete('SELECT `TACHE_ID`,`DESCRIPTION_TACHE` FROM `cra_taches` WHERE 1 ORDER BY `DESCRIPTION_TACHE` ASC');

		$data['collaborateurs']=$this->Model->getRequete('SELECT `ID_COLLABORATEUR`,`NOM`,`PRENOM` FROM `cra_collaborateur` WHERE 1 ORDER BY `NOM` ASC');

		$data['data']=$this->Model->getOne('cra_tache_affectation',array('TACHE_AFFECTATION_ID'=>$id));	

		// $id_collabo=$this->Model->getRequete('SELECT `ID_COLLABORATEUR` FROM cra_tache_affectation WHERE `TACHE_ID`='.$id);
		// foreach ($id_collabo as $value) {

		// 	 $vil[]=$value['ID_COLLABORATEUR'];
		// }
  //   $data['exist']=$vil;

    $data['title'] = 'Modification d\'une affectation';
		$this->load->view('Affectation_Update_View',$data);
	}


	function update()
	{
		$this->form_validation->set_rules('TACHE_ID','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('DATE_DEBUT','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('DATE_FIN','', 'trim|required',array('required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		$this->form_validation->set_rules('ID_COLLABORATEUR[]','', 'trim|required',array(
			'required'=>'<font style="color:red;size:2px;">Le champ est Obligatoire</font>'));

		if ($this->form_validation->run() == FALSE)
		{

			 $this->getOne();
		}else{
			$id=$this->input->post('TACHE_AFFECTATION_ID'); 
     

      $TACHE_ID=$this->input->post('TACHE_ID');

			$indicateur=$this->Model->getRequeteOne('SELECT `ID_KPI` FROM `cra_taches` WHERE `TACHE_ID`='.$TACHE_ID);
			$ID_KPI=$indicateur['ID_KPI'];

			$resultat=$this->Model->getRequeteOne('SELECT `ID_RESULTAT` FROM `cra_taches` WHERE `TACHE_ID`='.$TACHE_ID);
			$ID_RESULTAT=$resultat['ID_RESULTAT'];

			$projet=$this->Model->getRequeteOne('SELECT `ID_PROJET` FROM `cra_taches` WHERE `TACHE_ID`='.$TACHE_ID);
			$ID_PROJET=$projet['ID_PROJET'];


			$data_array=array(
					'TACHE_ID'=>$this->input->post('TACHE_ID'),
					'ID_KPI'=>$ID_KPI,
					'ID_RESULTAT'=>$ID_RESULTAT,
					'DATE_DEBUT'=>$this->input->post('DATE_DEBUT'),
					'DATE_FIN'=>$this->input->post('DATE_FIN'),
					'ID_PROJET'=>$ID_PROJET,
					'ID_USER'=>$this->session->userdata('WASILI_EAT_USER_ID'),
					'ID_COLLABORATEUR'=>$this->input->post('ID_COLLABORATEUR'),
					);

// print_r($this->input->post('ID_COLLABORATEUR'));die();
			$this->Model->update('cra_tache_affectation',array('TACHE_AFFECTATION_ID'=>$id),$data_array);

	    $data['message']='<div class="alert alert-success text-center" id="message">'."La modification de l'affectation sur la tâche <b> ".' '.$data['rows']['DESCRIPTION_TACHE'].' </b> '." est faite avec succès".'</div>';
	    $this->session->set_flashdata($data);
	    redirect(base_url('cra/Affectation/'));			

		}
	}


	function delete()
	{
		$table="cra_tache_affectation";
	    $criteres['TACHE_AFFECTATION_ID']=$this->uri->segment(4);

	    $this->Model->delete($table,$criteres);
	    $data['message']='<div class="alert alert-success text-center" id="message">'."L'affectation <b> ".' '.$data['rows']['DESCRIPTION_TACHE'].' </b> '." est supprimée avec succès".'</div>';
	    $this->session->set_flashdata($data);
	    redirect(base_url('cra/Affectation/'));
	}

}
 ?>