<?php 

$config['indicatifs'] = array(
	                          "1"=>array(79,71,76,72),
	                          "2"=>array(69,68,61,31),
	                          "3"=>array(77,22),
	                          "4"=>array(75)
	                      );


?>